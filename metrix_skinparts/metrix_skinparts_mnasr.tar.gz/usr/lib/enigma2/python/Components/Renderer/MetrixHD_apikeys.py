#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
from Components.config import config
from pathlib import Path
from threading import Lock

api_lock = Lock()

API_KEYS = {
	"tmdb_api": "3c3efcf47c3577558812bb9d64019d65",
	"omdb_api": "4ca6ea60",
	"thetvdb_api": "a99d487bb3426e5f3a60dea6d3d3c7ef",
	"fanart_api": "6d231536dea4318a88cb2520ce89473b",
}

def _load_api_keys():
	try:
		cur_skin = config.skin.primary_skin.value.replace("/skin.xml", "")
		skin_path = Path(f"/usr/share/enigma2/{cur_skin}")

		if not skin_path.exists():
			return False

		key_files = {
			"tmdb_api": skin_path / "tmdb_api",
			"omdb_api": skin_path / "omdb_api",
			"thetvdb_api": skin_path / "thetvdb_api",
			"fanart_api": skin_path / "fanart_api"
		}

		keys_loaded = False
		with api_lock:
			for key_name, file_path in key_files.items():
				if file_path.exists():
					try:
						with open(file_path, "r") as f:
							key_value = f.read().strip()
							if key_value:
								API_KEYS[key_name] = key_value
						keys_loaded = True
					except Exception as e:
						print(f"[API Config] Error reading {file_path}: {str(e)}")

		return keys_loaded
	except Exception as e:
		print(f"[API Config] Critical error loading keys: {str(e)}")
		return False

if not _load_api_keys():
	print("[API Config] Using default API keys")