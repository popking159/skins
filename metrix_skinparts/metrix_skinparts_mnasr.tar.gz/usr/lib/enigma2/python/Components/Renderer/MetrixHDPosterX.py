#!/usr/bin/python
# -*- coding: utf-8 -*-
###################################
##__author__ = "Lululla"         ##
##__copyright__ = "AGP Team"     ##
##__modified_by__ = "MNASR"      ##
###################################
from __future__ import absolute_import, print_function
# Standard library
from datetime import datetime
from os import remove, makedirs
from os.path import join, exists, getsize
from re import compile, sub
import threading
from threading import Thread, Lock
from datetime import timedelta
from time import sleep, time
from traceback import print_exc, format_exc
from collections import OrderedDict
from queue import Queue
# from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor

# Enigma2 specific imports
from enigma import ePixmap, loadJPG, eEPGCache, eTimer
from Components.Renderer.Renderer import Renderer
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
from ServiceReference import ServiceReference
import NavigationInstance

# Local imports
from .MetrixHD_apikeys import API_KEYS

class ApiKeyManager:
	# Define which providers strictly require an API key
	API_CONFIG = ["tmdb", "thetvdb", "fanart", "omdb"]

	def get_active_providers(self):
		return {
			"tmdb": True, 
			"fanart": True, 
			"thetvdb": True, 
			"omdb": True,
			"elcinema": True,
			"google": True,
			"imdb": True,
			"programmetv": True,
			"molotov": True
		}

	def get_api_key(self, provider_name):
		# Dynamically pull the API key from MetrixHD_apikeys.py
		return API_KEYS.get(f"{provider_name}_api", "")

class DummyCfg:
	# Mock configuration for the AutoDB schedulers
	class pstdown: value = False # Set True to enable auto-download for posters/logos
	class pscan_time: value = [0, 0]
	class bkddown: value = False # Set True to enable auto-download for backdrops
	class bscan_time: value = [0, 0]

cfg = DummyCfg()
from Components.Renderer.MetrixHDpDownloadThread import MetrixHDpDownloadThread
from .MetrixHD_Utils import (
	POSTER_FOLDER,
	check_disk_space,
	delete_old_files_if_low_disk_space,
	validate_media_path,
	# MemClean,
	clean_for_tvdb,
	logger,
	create_secure_log_dir
)
from .MetrixHD_lib import build_search_title, clean_search_title, smart_capitalize_title, should_skip_title

secure_log_dir = create_secure_log_dir()

if not POSTER_FOLDER.endswith("/"):
	POSTER_FOLDER += "/"

# Constants and global variables
epgcache = eEPGCache.getInstance()
epgcache.load()
pdb = Queue()
# Create an API Key Manager instance
api_key_manager = ApiKeyManager()

extensions = ['.jpg']
autobouquet_file = None
apdb = dict()
SCAN_TIME = "00:00"


def get_search_title(title, shortdesc="", fulldesc=""):
	try:
		result = build_search_title(title or "", shortdesc or "", fulldesc or "")
		return smart_capitalize_title(result)
	except Exception:
		return smart_capitalize_title(clean_search_title(title or ""))

global global_agp_auto_db
AgpDB = None
db_lock = Lock()
global_agp_auto_db = None


"""
Use:
# for infobar,
<widget source="session.Event_Now" render="MetrixHDPosterX" position="100,100" size="185,278" />
<widget source="session.Event_Next" render="MetrixHDPosterX" position="100,100" size="100,150" />
<widget source="session.Event_Now" render="MetrixHDPosterX" position="100,100" size="185,278" nexts="2" />
<widget source="session.CurrentService" render="MetrixHDPosterX" position="100,100" size="185,278" nexts="3" />

# for ch,
<widget source="ServiceEvent" render="MetrixHDPosterX" position="100,100" size="185,278" />
<widget source="ServiceEvent" render="MetrixHDPosterX" position="100,100" size="185,278" nexts="2" />

# for epg, event
<widget source="Event" render="MetrixHDPosterX" position="100,100" size="185,278" />
<widget source="Event" render="MetrixHDPosterX" position="100,100" size="185,278" nexts="2" />
# or/and put tag -->  path="/media/hdd/poster"
"""

"""
ADVANCED CONFIGURATIONS:
<widget source="ServiceEvent" render="MetrixHDPosterX"
	nexts="1"
	position="1202,672"
	size="200,300"
	cornerRadius="20"
	zPosition="95"
	path="/path/to/custom_folder"   <!-- Optional -->
/>
"""


class MetrixHDPosterX(Renderer):
	"""
	Main Poster renderer class for Enigma2
	Handles Poster display and refresh logic

	Features:
	- Dynamic poster loading based on current program
	- Automatic refresh when channel/program changes
	- Multiple image format support
	- Skin-configurable providers
	- Asynchronous poster loading
	"""
	GUI_WIDGET = ePixmap

	def __init__(self):
		"""Initialize the poster renderer"""
		Renderer.__init__(self)

		self._stop_event = threading.Event()
		self._active_event = threading.Event()
		self._active_event.set()
		self.poster_cache = {}
		self.queued_posters = set()
		self.storage_path = POSTER_FOLDER
		self.extensions = extensions
		self.providers = {}
		self.nxts = 0

		self.canal = [None] * 6
		self.oldCanal = None
		self.pstcanal = None
		self.pstrNm = None
		self.backrNm = None
		self.poster_refresh_count = 0
		self.poster_refresh_max = 20
		self.poster_refresh_delay = 300
		self.log_file = join(secure_log_dir, "MetrixHDPosterX.log")
		clear_all_log()

		self.adsl = True

		if len(self.poster_cache) > 50:
			self.poster_cache.clear()

		self.show_timer = eTimer()
		self.show_timer.callback.append(self.refreshPoster)

		self.providers = api_key_manager.get_active_providers()

		global AgpDB, global_agp_auto_db

		self.poster_db = AgpDB
		self.poster_auto_db = global_agp_auto_db

		# -------------------------------------------------
		# logger.info("MetrixHDPosterX Renderer initialized")
		# logger.debug(f"Path archiving: {self.storage_path}")
		# logger.debug(f"Provider actives: {list(self.providers.keys())}")

	def applySkin(self, desktop, parent):
		attribs = []
		for attrib, value in self.skinAttributes:
			if attrib == "nexts":
				try:
					self.nxts = int(value)
				except Exception:
					self.nxts = 0
			elif attrib == "path":
				self.storage_path = str(value)
				try:
					if not exists(self.storage_path):
						makedirs(self.storage_path, exist_ok=True)
				except Exception as e:
					logger.error("Failed to create poster path {}: {}".format(self.storage_path, str(e)))
			else:
				attribs.append((attrib, value))

		self.skinAttributes = attribs
		return Renderer.applySkin(self, desktop, parent)

	def changed(self, what):
		"""Handle screen/channel changes and update poster"""
		if not self.instance:
			return

		# Skip unnecessary updates
		if what[0] not in (self.CHANGED_DEFAULT, self.CHANGED_ALL, self.CHANGED_SPECIFIC, self.CHANGED_CLEAR):
			if self.instance:
				self.instance.hide()
			return

		source = self.source
		source_type = type(source)
		servicetype = None
		service = None
		try:
			# Handle different source types
			if source_type is ServiceEvent:
				service = source.getCurrentService()
				servicetype = "ServiceEvent"
			elif source_type is CurrentService:
				service = source.getCurrentServiceRef()
				servicetype = "CurrentService"
			elif source_type is EventInfo:
				service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
				servicetype = "EventInfo"
			elif source_type is Event:
				servicetype = "Event"

				if self.nxts:
					service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
					# print('fallback service:', service)
				else:
					if getattr(source, "event", None) is None:
						logger.info("MetrixHDPosterX: Event source has no event yet")
						self.oldCanal = None  # <-- ADD THIS LINE
						if self.instance:
							self.instance.hide()
						return

					event = source.event

					bt = event.getBeginTime()
					if bt is not None:
						self.canal[1] = bt

					event_name = sub(r"[\u0000-\u001F\u007F-\u009F]", "", event.getEventName() or "")
					if not event_name:
						logger.info("MetrixHDPosterX: Event source has empty event name")
						self.oldCanal = None  # <-- ADD THIS LINE
						if self.instance:
							self.instance.hide()
						return

					self.canal[2] = event_name
					self.canal[3] = event.getExtendedDescription()
					self.canal[4] = event.getShortDescription()
					self.canal[5] = event_name
			else:
				servicetype = None

			if service is not None:
				service_str = service.toString()
				# self._log_debug(f"Service string: {service_str}")
				events = epgcache.lookupEvent(['IBDCTESX', (service_str, 0, -1, -1)])

				if not events or len(events) <= self.nxts:
					# self._log_debug("No events or insufficient events")
					self.oldCanal = None  # <-- ADD THIS LINE
					if self.instance:
						self.instance.hide()
					return

				service_name = ServiceReference(service).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
				# self._log_debug(f"Service name: {service_name}")
				self.canal = [None] * 6
				self.canal[0] = service_name
				self.canal[1] = events[self.nxts][1]
				self.canal[2] = events[self.nxts][4]
				self.canal[3] = events[self.nxts][5]
				self.canal[4] = events[self.nxts][6]
				self.canal[5] = self.canal[2]
				# self._log_debug(f"Event data set: {self.canal}")

				if not autobouquet_file and service_name not in apdb:
					apdb[service_name] = service_str

			# Skip if no valid program data
			if not servicetype or not self.canal[5]:
				self.oldCanal = None  # <-- ADD THIS LINE
				if self.instance:
					self.instance.hide()
				return

			# Check if program changed
			curCanal = f"{self.canal[1]}-{self.canal[2]}"
			if curCanal == self.oldCanal:
				return

			if self.instance:
				self.instance.hide()

			self.oldCanal = curCanal
			self.pstcanal = get_search_title(self.canal[5], self.canal[4], self.canal[3])
			if not self.pstcanal:
				return

			skip_title, skip_word = should_skip_title(self.pstcanal)
			if skip_title:
				logger.info(f"Skipping before queue: original='{self.canal[2]}' | final_search_title='{self.pstcanal}' | matched_exclusion='{skip_word}' | channel='{self.canal[0]}'")
				return

			if self.pstcanal in self.poster_cache:
				cached_path = self.poster_cache[self.pstcanal]
				if checkPosterExistence(cached_path):
					self.showPoster(cached_path)
					return

			# Try to display existing poster
			poster_path = join(self.storage_path, f"{self.pstcanal}.jpg")
			self.backrNm = poster_path
			self.poster_refresh_count = 0

			if checkPosterExistence(poster_path):
				if not self.showPoster(poster_path):
					try:
						self.show_timer.start(self.poster_refresh_delay, True)
					except Exception:
						pass
			else:
				pdb.put(self.canal[:])
				self.runPosterThread()
				try:
					self.show_timer.start(self.poster_refresh_delay, True)
				except Exception:
					pass

		except Exception as e:
			logger.error(f"Error in changed: {str(e)}")
			if self.instance:
				self.instance.hide()
			return

	def generatePosterPath(self):
		"""Generate filesystem path for current program's poster"""
		if len(self.canal) > 5 and self.canal[5]:
			self.pstcanal = get_search_title(self.canal[5], self.canal[4], self.canal[3])
			return join(self.storage_path, str(self.pstcanal) + ".jpg")
		return None

	def runPosterThread(self):
		"""Start background thread to wait for poster download"""
		"""
		# for provider in self.providers:
			# if str(self.providers[provider]).lower() == "true":
				# self._log_debug(f"Providers attivi: {provider}")
		"""
		# Thread(target=self.waitPoster).start()
		Thread(target=self.waitPoster, daemon=True).start()

	def showPoster(self, poster_path=None):
		if not self.instance:
			return False

		if not poster_path and self.backrNm:
			poster_path = self.backrNm

		if not poster_path or not checkPosterExistence(poster_path):
			self.instance.hide()
			return False

		self.backrNm = poster_path

		try:
			pixmap = loadJPG(poster_path)
			if pixmap:
				self.instance.hide()
				self.instance.setPixmap(pixmap)
				self.instance.setScale(1)
				self.instance.show()
				return True
		except Exception as e:
			logger.warning("Poster load failed | file='{}' | error='{}'".format(poster_path, str(e)))

		self.instance.hide()
		return False

	def refreshPoster(self):
		if not self.backrNm:
			return

		if self.showPoster(self.backrNm):
			self.poster_refresh_count = 0
			return

		self.poster_refresh_count += 1

		if self.poster_refresh_count < self.poster_refresh_max:
			try:
				self.show_timer.start(self.poster_refresh_delay, True)
			except Exception:
				pass
		else:
			logger.info("Poster refresh stopped | file='{}'".format(self.backrNm))
			self.poster_refresh_count = 0

	def waitPoster(self):
		if not self.instance or not self.canal[5]:
			return

		pstcanal = get_search_title(self.canal[5], self.canal[4], self.canal[3])
		poster_path = join(self.storage_path, "%s.jpg" % pstcanal)

		self.backrNm = poster_path
		self.poster_refresh_count = 0

		try:
			self.show_timer.start(self.poster_refresh_delay, True)
		except Exception:
			pass

	def check_valid_poster(self, path):
		"""Verify Poster is valid JPEG and >1KB"""
		try:
			if not exists(path):
				return False

			if getsize(path) < 1024:
				remove(path)
				return False

			with open(path, 'rb') as f:
				header = f.read(2)
				if header != b'\xFF\xD8':  # JPEG magic number
					remove(path)
					return False
			return True
		except Exception as e:
			logger.error(f"Poster validation error: {str(e)}")
			return False

	def _log_info(self, message):
		self._write_log("INFO", message)

	def _log_debug(self, message):
		self._write_log("DEBUG", message)

	def _log_error(self, message):
		self._write_log("ERROR", message, error=True)

	def _write_log(self, level, message, error=False):
		"""Centralized logging method writing to fixed log files"""
		try:
			if not hasattr(self, "log_dir"):
				log_dir = secure_log_dir

			if not exists(log_dir):
				makedirs(log_dir)

			if error:
				log_file = log_dir + "/PosterX_errors.log"
			else:
				log_file = log_dir + "/PosterX.log"

			with open(log_file, "a") as w:
				w.write("{} {}: {}\n".format(datetime.now(), level, message))
		except Exception as e:
			print("Logging error: {}".format(e))


class PosterDB(MetrixHDpDownloadThread):

	"""Handles Poster downloading and database management"""
	def __init__(self, providers=None):
		# MetrixHDpDownloadThread.__init__()
		super().__init__()

		self.providers = {}
		self.poster_cache = {}
		self.provider_engines = []
		self.pstcanal = None
		self.logdbg = None
		self.extensions = extensions
		self.queued_posters = set()
		self.executor = ThreadPoolExecutor(max_workers=1)
		logger.info("PosterDB executor configured | max_workers='1'")
		self.service_pattern = compile(r'^#SERVICE (\d+):([^:]+:[^:]+:[^:]+:[^:]+:[^:]+:[^:]+)')

		self.log_file = join(secure_log_dir, "PosterDB.log")

		self.providers = api_key_manager.get_active_providers()
		self.provider_engines = self.build_providers()

	def build_providers(self):
		"""Initialize enabled provider search engines"""
		provider_mapping = {
			"tmdb": self.search_tmdb,
			"fanart": self.search_fanart,
			"thetvdb": self.search_tvdb,
			"elcinema": self.search_elcinema,  # no apikey
			"google": self.search_google,  # no apikey
			"omdb": self.search_omdb,
			"imdb": self.search_imdb,  # no apikey
			"programmetv": self.search_programmetv_google,  # no apikey
			"molotov": self.search_molotov_google,  # no apikey
		}
		return [
			(name, func) for name, func in provider_mapping.items()
			if self.providers.get(name, False)
		]

	def run(self):
		"""Main processing loop - handles incoming channel requests"""
		while True:
			canal = pdb.get()
			self.process_canal(canal)
			pdb.task_done()

	def process_canal(self, canal):
		"""Schedule channel processing in thread pool"""
		self.executor.submit(self._process_canal_task, canal)

	def _process_canal_task(self, canal):
		"""Download and process poster for a single channel"""
		try:
			self.pstcanal = get_search_title(canal[5], canal[4], canal[3])
			if not self.pstcanal:
				logger.error(f"Invalid channel: {canal[0]}")
				return

			skip_title, skip_word = should_skip_title(self.pstcanal)
			if skip_title:
				logger.info(f"Skipping title: original='{canal[2]}' | final_search_title='{self.pstcanal}' | matched_exclusion='{skip_word}' | channel='{canal[0]}'")
				return

			poster_path = join(POSTER_FOLDER, f"{self.pstcanal}.jpg")

			# Check if already in the queue
			"""
			if self.pstcanal in self.queued_posters:
				logger.debug(f"Poster already queued: {self.pstcanal}")
				return
			"""
			# Add to queue and process
			with Lock():
				self.queued_posters.add(self.pstcanal)

			try:
				# Check if a valid file already exists
				if self.check_valid_poster(poster_path):
					# logger.debug(f"Valid existing poster: {poster_path}")
					return

				logger.info(
					f"Starting download: original='{canal[2]}' | clean_for_tvdb='{clean_for_tvdb(canal[5])}' | final_search_title='{self.pstcanal}' | channel='{canal[0]}'"
				)

				# Sort providers by configured priority
				sorted_providers = sorted(
					self.provider_engines,
					key=lambda x: self.providers.get(x[0], 0),
					reverse=True
				)

				for provider_name, provider_func in sorted_providers:
					try:
						# Only providers in API_CONFIG require keys; keyless providers must run normally
						api_key = api_key_manager.get_api_key(provider_name)
						if provider_name in api_key_manager.API_CONFIG and not api_key:
							logger.warning(f"Missing API key for {provider_name}")
							continue

						# Call the provider function to download the poster
						result = provider_func(
							dwn_poster=poster_path,
							title=self.pstcanal,
							shortdesc=canal[4],
							fulldesc=canal[3],
							channel=canal[0],
							api_key=api_key
						)
						if result and self.check_valid_poster(poster_path):
							logger.info(f"Download successful with {provider_name}")
							break

					except Exception as e:
						logger.error(f"Error from {provider_name}: {str(e)}")
						continue

			finally:
				# Remove the channel from the queue after processing
				with Lock():
					self.queued_posters.discard(self.pstcanal)

		except Exception as e:
			logger.error(f"Critical error in _process_canal_task: {str(e)}")
			logger.error(format_exc())

	def check_valid_poster(self, path):
		"""Verify poster is valid JPEG and >1KB"""
		try:
			if not exists(path):
				return False

			if getsize(path) < 1024:
				remove(path)
				return False

			with open(path, 'rb') as f:
				header = f.read(2)
				if header != b'\xFF\xD8':  # JPEG magic number
					remove(path)
					return False
			return True
		except Exception as e:
			logger.error(f"Poster validation error: {str(e)}")
			return False

	# def update_poster_cache(self, poster_name, path):
		# """Force update cache entry"""
		# self.poster_cache[poster_name] = path
		# # Limit cache size
		# if len(self.poster_cache) > 50:
			# oldest = next(iter(self.poster_cache))
			# del self.poster_cache[oldest]

	def mark_failed_attempt(self, canal_name):
		"""Track failed download attempts"""
		self._log_debug(f"Failed attempt for {canal_name}")

	def _log_info(self, message):
		self._write_log("INFO", message)

	def _log_debug(self, message):
		self._write_log("DEBUG", message)

	def _log_error(self, message):
		self._write_log("ERROR", message, error=True)

	def _write_log(self, level, message, error=False):
		"""Centralized logging method writing to fixed log files"""
		try:
			if not hasattr(self, "log_dir"):
				log_dir = secure_log_dir

			if not exists(log_dir):
				makedirs(log_dir)

			if error:
				log_file = log_dir + "/PosterX_errors.log"
			else:
				log_file = log_dir + "/PosterX.log"

			with open(log_file, "a") as w:
				w.write("{} {}: {}\n".format(datetime.now(), level, message))
		except Exception as e:
			print("Logging error: {}".format(e))


class PosterAutoDB(MetrixHDpDownloadThread):
	"""Automatic Poster download scheduler

	Features:
	- Scheduled daily scans (configurable)
	- Batch processing for efficiency
	- Automatic retry mechanism
	- Provider fallback system

	Configuration:
	- providers: Configured via plugin setup parameters
	"""

	_instance = None

	def __init__(self, providers=None, max_posters=2000):
		"""Initialize the poster downloader with provider configurations"""
		"""
		# if hasattr(self, '_initialized') and self._initialized:
			# return
		"""
		super().__init__()
		# MetrixHDpDownloadThread.__init__(self)
		# self._initialized = True
		self._stop_event = threading.Event()
		self._active_event = threading.Event()
		self._scan_lock = Lock()
		self.poster_download_count = 0
		self.max_posters = max_posters
		self.min_disk_space = 100
		self.max_poster_age = 30
		self.last_scan = 0

		self.apdb = OrderedDict()
		self.service_queue = []
		self.processed_titles = OrderedDict()
		self.provider_engines = []

		self.providers = {}
		self.pstcanal = None
		self.extensions = extensions
		self.poster_folder = "/tmp/posters"
		if not exists(self.poster_folder):
			makedirs(self.poster_folder, mode=0o700)
		self.scheduled_hour = 0
		self.scheduled_minute = 0
		self.last_scheduled_run = None
		self.log_file = join(secure_log_dir, "PosterAutoDB.log")
		self.daemon = True
		self.force_immediate = False
		self.active = False
		self._active_event.set()

		if not cfg.pstdown.value:
			# logger.debug("PosterAutoDB: Automatic downloads DISABLED in configuration")
			return

		if not any(api_key_manager.get_active_providers().values()):
			# logger.debug("Disabled - no active provider")
			return

		# Proceed with full initialization
		self.active = True
		self.providers = api_key_manager.get_active_providers()
		self.poster_folder = self._init_poster_folder()
		self.provider_engines = self.build_providers()
		logger.debug("PosterAutoDB: Automatic downloads ENABLED in configuration")
		try:
			scan_time = cfg.pscan_time.value
			self.scheduled_hour = int(scan_time[0])
			self.scheduled_minute = int(scan_time[1])
			logger.debug(f"Configured time: {self.scheduled_hour:02d}:{self.scheduled_minute:02d}")
		except Exception as e:
			logger.error("Error parsing scan time: " + str(e))

		if not exists("/tmp/agplog"):
			makedirs("/tmp/agplog")
		self._log_info("=== INITIALIZATION COMPLETE ===")
		self._log_info("=== READY ===")

	def __new__(cls, *args, **kwargs):
		if cls._instance is None:
			cls._instance = super().__new__(cls)
		return cls._instance

	def build_providers(self):
		active_providers = api_key_manager.get_active_providers()
		valid_providers = []
		provider_mapping = {
			"tmdb": self.search_tmdb,
			"fanart": self.search_fanart,
			"thetvdb": self.search_tvdb,
			"elcinema": self.search_elcinema,  # no apikey
			"google": self.search_google,  # no apikey
			"omdb": self.search_omdb,
			"imdb": self.search_imdb,  # no apikey
			"programmetv": self.search_programmetv_google,  # no apikey
			"molotov": self.search_molotov_google,  # no apikey
		}
		for name, func in provider_mapping.items():
			if active_providers.get(name, False):
				if name in ["tmdb", "fanart", "omdb"]:  # Providers requiring API keys
					key = api_key_manager.get_api_key(name)
					if not key:
						logger.error(f"Invalid API key for {name}")
						continue
				valid_providers.append((name, func))

		logger.debug(f"Active providers: {[p[0] for p in valid_providers]}")
		return valid_providers

	@property
	def active(self):
		return self._active_event.is_set()

	@active.setter
	def active(self, value):
		if value:
			self._active_event.set()
		else:
			self._active_event.clear()

	def start(self):
		if not self.is_alive():
			self.active = True
			super().start()

	def run(self):
		logger.info("PosterAutoDB THREAD STARTED")
		# logger.info("RUNNING IN TEST MODE - BYPASSING SCHEDULER")
		# self._execute_scheduled_scan()  # Force immediate scan
		# logger.info("TEST SCAN COMPLETED")
		try:
			while not self._stop_event.is_set():
				if self.force_immediate:
					logger.debug("FORCED IMMEDIATE SCAN!")
					self._execute_scheduled_scan()
					self.force_immediate = False
					continue

				now = datetime.now()
				next_run = self._calculate_next_run(now)
				logger.debug(f"Scheduled for: {next_run}")

				while datetime.now() < next_run and not self._stop_event.is_set():
					remaining = (next_run - datetime.now()).total_seconds()
					# logger.debug(f"Residual wait: {remaining:.1f}s")

					for _ in range(int(min(remaining, 1))):
						if self._stop_event.is_set() or self.force_immediate:
							break
						sleep(1)

					if self.force_immediate:
						logger.debug("Interrupt waiting for manual scan")
						break

				if not self._stop_event.is_set():
					logger.debug("=== SCHEDULED SCAN START ===")
					self._execute_scheduled_scan()

		except Exception as e:
			logger.error(f"ERROR: {str(e)}", exc_info=True)
		finally:
			logger.info("PosterAutoDB STOPPED")

	def _execute_immediate_scan(self):
		with self._scan_lock:
			logger.debug("Starting immediate scan")
			self._full_scan()
			self._process_services()
			self.force_immediate = False
			self._stop_event.set()
			self._stop_event.clear()

	def _calculate_next_run(self, current_time):
		if self.force_immediate:
			return current_time - timedelta(seconds=1)

		next_run = datetime(
			year=current_time.year,
			month=current_time.month,
			day=current_time.day,
			hour=self.scheduled_hour,
			minute=self.scheduled_minute,
			second=0
		)
		if next_run <= current_time:
			next_run += timedelta(days=1)

		logger.debug(f"Next scan: {next_run.strftime('%Y-%m-%d %H:%M:%S')}")
		return next_run

	def _execute_scheduled_scan(self):
		"""Run a single scheduled scan"""
		with self._scan_lock:
			if self.active:
				logger.debug("Starting scheduled scan")
				self._full_scan()
				self._process_services()
				self.last_scan = time()
				logger.debug("Scheduled scan completed")

	def stop(self):
		"""Safe stop with timeout"""
		self.active = False
		self._active_event.set()
		if self.is_alive():
			self.join(timeout=2.0)
		logger.debug("PosterAutoDB fully stopped")

	def _cleanup(self):
		self.active = False
		logger.info("PosterAutoDB stopped gracefully")

	def _full_scan(self):
		"""Scan all available TV services"""
		self._log_info("Starting full service scan")
		self.service_queue = self._load_services()
		self._log_info(f"Scan completed, found {len(self.service_queue)} services")

	def _load_services(self):
		"""Load services from Enigma2 bouquet files"""
		services = OrderedDict()
		fav_path = "/etc/enigma2/userbouquet.favourites.tv"
		bouquets = [fav_path] if exists(fav_path) else []

		main_path = "/etc/enigma2/bouquets.tv"
		if exists(main_path):
			try:
				with open(main_path, "r") as f:
					bouquets += [
						"/etc/enigma2/" + line.split("\"")[1]
						for line in f
						if line.startswith("#SERVICE") and "FROM BOUQUET" in line
					]
			except Exception as e:
				self._log_error(f"Error reading bouquets.tv: {str(e)}")

		for bouquet in bouquets:
			if exists(bouquet):
				try:
					with open(bouquet, "r", encoding="utf-8", errors="ignore") as f:
						for line in f:
							line = line.strip()
							if line.startswith("#SERVICE") and "FROM BOUQUET" not in line:
								service_ref = line[9:]
								if self._is_valid_service(service_ref):
									services[service_ref] = None
									self.apdb[service_ref] = service_ref
				except Exception as e:
					self._log_error(f"Error reading bouquet {bouquet}: {str(e)}")

		return list(services.keys())

	def _is_valid_service(self, sref):
		"""Validate service reference format"""
		parts = sref.split(':')
		if len(parts) < 6:
			return False
		return parts[3:6] != ["0", "0", "0"]

	def _process_services(self):
		"""Process all services and download posters"""
		for service_ref in self.apdb.values():
			try:
				events = epgcache.lookupEvent(['IBDCTESX', (service_ref, 0, -1, 1440)])
				if not events:
					self._log_debug(f"No EPG data for service: {service_ref}")
					continue

				for evt in events:
					canal = self._prepare_canal_data(service_ref, evt)
					if canal:
						self._download_poster(canal)

			except Exception as e:
				self._log_error(f"Error processing service {service_ref}: {str(e)}")
				print_exc()

	def _prepare_canal_data(self, service_ref, event):
		try:
			# Get service name from service reference
			service_name = ServiceReference(service_ref).getServiceName()
			service_name = service_name.replace("\xc2\x86", "").replace("\xc2\x87", "")

			# Safely get the raw event title (could be None)
			raw_title = event[4] or ""
			event_name = raw_title.strip()
			if not event_name:
				# nothing to search for, skip this event
				return None

			clean_title = get_search_title(event_name, event[6], event[5])

			logger.debug(f"Processing event: {event_name} -> {clean_title}")

			return [
				service_name,
				event[1],      # begin_time
				event_name,
				event[5],      # extended_desc
				event[6],      # short_desc
				clean_title,
			]

		except Exception as e:
			logger.error(f"Failed to parse event: {str(e)}")
			return None

	def _download_poster(self, canal):
		"""Download poster with provider fallback logic"""
		try:
			if not self._pre_download_checks(canal):
				return
			downloaded = False
			for provider_name, provider_func in self.provider_engines:
				if self._try_provider(provider_name, provider_func, canal):
					downloaded = True
					break
			if not downloaded:
				logger.error(f"Download failed for: {self.pstcanal}")
		except Exception as e:
			logger.error(f"Critical error: {str(e)}")
			print_exc()

	def _pre_download_checks(self, canal):
		"""Run pre-download checks"""
		if not canal or len(canal) < 6:
			return False

		self.pstcanal = get_search_title(canal[5] or "", canal[4], canal[3])
		if not self.pstcanal:
			return False

		skip_title, skip_word = should_skip_title(self.pstcanal)
		if skip_title:
			logger.info(f"Skipping auto-download: original='{canal[2]}' | final_search_title='{self.pstcanal}' | matched_exclusion='{skip_word}' | channel='{canal[0]}'")
			return False

		if self.poster_download_count >= self.max_posters:
			return False

		if not self._check_storage():
			self._log_info("Download skipped due to insufficient storage")
			return False

		if not check_disk_space(POSTER_FOLDER, 10):
			logger.warning("Not enough space to download")
			return False

		return True

	def _try_provider(self, provider_name, provider_func, canal):
		"""Try downloading with a specific provider"""
		try:
			api_key = api_key_manager.get_api_key(provider_name)
			if provider_name in api_key_manager.API_CONFIG and not api_key:
				logger.warning(f"Missing API key for {provider_name}")
				return False
			# logger.debug(f"Trying {provider_name} with key: {api_key[:3]}...")
			poster_path = join(POSTER_FOLDER, f"{self.pstcanal}.jpg")
			# logger.debug(f"Searching: {self.pstcanal} | Channel: {canal[0]}")
			result = provider_func(
				dwn_poster=poster_path,
				title=self.pstcanal,
				shortdesc=canal[4],
				fulldesc=canal[3],
				channel=canal[0],
				api_key=api_key
			)
			if result:
				logger.debug(f"{provider_name} returned URL: {result}")
				if self._validate_download(poster_path):
					return True
			else:
				logger.debug(f"{provider_name} returned no results")

		except Exception as e:
			logger.error(f"Error with {provider_name}: {str(e)}")

		return False

	def _validate_download(self, poster_path):
		"""Verify the integrity of the downloaded file"""
		if checkPosterExistence(poster_path) and getsize(poster_path) > 1024:
			self.poster_download_count += 1
			return True
		return False

	def _init_poster_folder(self):
		"""Initialize the folder with validation"""
		try:
			return validate_media_path(
				POSTER_FOLDER,
				media_type="posters",
				min_space_mb=self.min_disk_space
			)
		except Exception as e:
			self._log_error(f"Poster folder init failed: {str(e)}")
			fallback = "/tmp/posters"
			try:
				if not exists(fallback):
					makedirs(fallback, mode=0o700)
			except BaseException:
				pass
			return fallback

	def _check_storage(self):
		"""Version optimized using utilities"""
		try:
			if check_disk_space(self.poster_folder, self.min_disk_space):
				return True

			self._log_info("Low disk space detected, running cleanup...")
			delete_old_files_if_low_disk_space(
				self.poster_folder,
				min_free_space_mb=self.min_disk_space,
				max_age_days=self.max_poster_age
			)

			return check_disk_space(self.poster_folder, self.min_disk_space)

		except Exception as e:
			self._log_error(f"Storage check failed: {str(e)}")
			return False

	def _log_info(self, message):
		self._write_log("INFO", message)

	def _log_debug(self, message):
		self._write_log("DEBUG", message)

	def _log_error(self, message):
		self._write_log("ERROR", message, error=True)

	def _write_log(self, level, message, error=False):
		"""Centralized logging method writing to fixed log files"""
		try:
			log_dir = "/tmp/agplog"
			if not exists(log_dir):
				makedirs(log_dir)

			# Choose file based on error flag
			if error:
				log_file = log_dir + "/PosterX_errors.log"
			elif level == "DEBUG":
				log_file = log_dir + "/PosterX.log"
			else:
				log_file = log_dir + "/PosterX.log"

			with open(log_file, "a") as w:
				w.write(f"{datetime.now()} {level}: {message}\n")
		except Exception as e:
			print(f"Logging error: {e}")


def checkPosterExistence(poster_path):
	return exists(poster_path)


def is_valid_poster(poster_path):
	"""Check if the poster file is valid (exists and has a valid size)"""
	return exists(poster_path) and getsize(poster_path) > 100


def clear_all_log():
	log_dir = secure_log_dir
	log_files = [
		log_dir + "/PosterX_errors.log",
		log_dir + "/PosterX.log",
		log_dir + "/PosterAutoDB.log"
	]
	for file in log_files:
		try:
			if exists(file):
				remove(file)
				logger.warning("Removed cache: {}".format(file))
		except Exception as e:
			logger.error("log_files cleanup failed: {}".format(e))


# download on requests
if any(api_key_manager.get_active_providers().values()):
	logger.debug("Starting PosterDB with active providers")
	with db_lock:
		if AgpDB is None or not AgpDB.is_alive():
			AgpDB = PosterDB()
			AgpDB.daemon = True
			AgpDB.start()
			logger.debug("PosterDB started with PID: %s" % AgpDB.ident)
else:
	logger.debug("PosterDB not started - no active providers")


# automatic download
if cfg.pstdown.value:
	logger.debug("Starting PosterAutoDB...")

	# Stop existing instance if any
	if global_agp_auto_db:
		global_agp_auto_db.stop()
		global_agp_auto_db = None

	# Start new instance
	global_agp_auto_db = PosterAutoDB()
	global_agp_auto_db.daemon = True
	global_agp_auto_db.start()
	logger.debug("PosterAutoDB ACTIVE")
